graph [
  node [
    id 0
    label "NZ_PP215914.1.fasta"
  ]
  node [
    id 1
    label "NZ_CP026060.1.fasta"
  ]
  node [
    id 2
    label "NZ_CP024853.1.fasta"
  ]
  node [
    id 3
    label "NZ_MW349106.1.fasta"
  ]
  node [
    id 4
    label "NZ_CP147126.1.fasta"
  ]
  node [
    id 5
    label "NZ_CP018108.1.fasta"
  ]
  node [
    id 6
    label "NC_020122.1.fasta"
  ]
  node [
    id 7
    label "NZ_CP018120.1.fasta"
  ]
  node [
    id 8
    label "NZ_CP027258.1.fasta"
  ]
  node [
    id 9
    label "NZ_LN824136.1.fasta"
  ]
  node [
    id 10
    label "NZ_LR890715.1.fasta"
  ]
  node [
    id 11
    label "CP142584.1.fasta"
  ]
  node [
    id 12
    label "NZ_CP067315.1.fasta"
  ]
  node [
    id 13
    label "NZ_CP029801.1.fasta"
  ]
  node [
    id 14
    label "NZ_CP006640.1.fasta"
  ]
  node [
    id 15
    label "NZ_CP018988.1.fasta"
  ]
  node [
    id 16
    label "NZ_OZ038591.1.fasta"
  ]
  node [
    id 17
    label "NZ_CP028999.1.fasta"
  ]
  node [
    id 18
    label "NZ_CP043224.1.fasta"
  ]
  node [
    id 19
    label "NZ_CP043184.1.fasta"
  ]
  node [
    id 20
    label "NZ_MT215579.2.fasta"
  ]
  node [
    id 21
    label "NZ_CP142705.1.fasta"
  ]
  node [
    id 22
    label "CP142532.1.fasta"
  ]
  node [
    id 23
    label "CP099160.1.fasta"
    type "singleton"
  ]
  node [
    id 24
    label "NZ_CP049103.1.fasta"
    type "singleton"
  ]
  node [
    id 25
    label "NZ_CP016009.1.fasta"
    type "singleton"
  ]
  node [
    id 26
    label "NZ_CP148367.1.fasta"
    type "singleton"
  ]
  node [
    id 27
    label "NZ_CP142709.1.fasta"
    type "singleton"
  ]
  node [
    id 28
    label "NC_025013.1.fasta"
    type "singleton"
  ]
  edge [
    source 0
    target 21
    weight 98.58757062146893
  ]
  edge [
    source 1
    target 2
    weight 96.6332457142857
  ]
  edge [
    source 1
    target 6
    weight 98.322
  ]
  edge [
    source 1
    target 8
    weight 85.842
  ]
  edge [
    source 1
    target 9
    weight 97.03572352941177
  ]
  edge [
    source 1
    target 13
    weight 91.84978823529411
  ]
  edge [
    source 1
    target 14
    weight 87.80522058823529
  ]
  edge [
    source 1
    target 15
    weight 91.46371764705881
  ]
  edge [
    source 1
    target 17
    weight 61.769495652173916
  ]
  edge [
    source 2
    target 6
    weight 95.63801714285715
  ]
  edge [
    source 2
    target 8
    weight 83.38551428571428
  ]
  edge [
    source 2
    target 9
    weight 96.54086285714286
  ]
  edge [
    source 2
    target 13
    weight 86.49070857142857
  ]
  edge [
    source 2
    target 14
    weight 82.85240294117646
  ]
  edge [
    source 2
    target 15
    weight 88.60520294117647
  ]
  edge [
    source 2
    target 17
    weight 66.09024782608695
  ]
  edge [
    source 3
    target 12
    weight 81.23105454545454
  ]
  edge [
    source 3
    target 18
    weight 97.61904761904762
  ]
  edge [
    source 3
    target 19
    weight 95.29153255813954
  ]
  edge [
    source 4
    target 11
    weight 76.59476582278481
  ]
  edge [
    source 4
    target 16
    weight 64.1266942857143
  ]
  edge [
    source 4
    target 22
    weight 70.75750000000001
  ]
  edge [
    source 5
    target 7
    weight 100.0
  ]
  edge [
    source 6
    target 8
    weight 82.8559
  ]
  edge [
    source 6
    target 9
    weight 95.55557647058824
  ]
  edge [
    source 6
    target 13
    weight 91.93402352941176
  ]
  edge [
    source 6
    target 14
    weight 85.43620588235294
  ]
  edge [
    source 6
    target 15
    weight 88.61851470588236
  ]
  edge [
    source 6
    target 17
    weight 63.36091304347826
  ]
  edge [
    source 8
    target 9
    weight 83.18914411764706
  ]
  edge [
    source 8
    target 13
    weight 86.31379411764705
  ]
  edge [
    source 8
    target 14
    weight 72.01764705882354
  ]
  edge [
    source 8
    target 15
    weight 87.50761764705881
  ]
  edge [
    source 8
    target 17
    weight 61.8827847826087
  ]
  edge [
    source 9
    target 13
    weight 89.2388794117647
  ]
  edge [
    source 9
    target 14
    weight 80.41715294117647
  ]
  edge [
    source 9
    target 15
    weight 96.9076
  ]
  edge [
    source 9
    target 17
    weight 67.89627826086956
  ]
  edge [
    source 10
    target 20
    weight 57.56277000000001
  ]
  edge [
    source 11
    target 16
    weight 58.25019367088607
  ]
  edge [
    source 11
    target 22
    weight 72.51407826086957
  ]
  edge [
    source 12
    target 18
    weight 81.22557272727273
  ]
  edge [
    source 12
    target 19
    weight 80.9365090909091
  ]
  edge [
    source 13
    target 14
    weight 88.63383235294117
  ]
  edge [
    source 13
    target 15
    weight 91.87971764705883
  ]
  edge [
    source 13
    target 17
    weight 68.22372173913044
  ]
  edge [
    source 14
    target 15
    weight 85.692
  ]
  edge [
    source 14
    target 17
    weight 65.06751739130435
  ]
  edge [
    source 15
    target 17
    weight 70.14099782608696
  ]
  edge [
    source 16
    target 22
    weight 54.011336024844724
  ]
  edge [
    source 18
    target 19
    weight 95.29153255813954
  ]
]
